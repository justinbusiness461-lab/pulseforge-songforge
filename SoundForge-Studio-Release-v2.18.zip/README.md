# PulseForge SongForge — Unified (Phases 1–4)

**Mobile-first · offline · zero-dependency** generative music studio.

## Quick start
```bash
cd pulseforge-songforge
python3 -m http.server 8765
# open http://localhost:8765
```
Phone: same Wi‑Fi → `http://<your-ip>:8765` · or Share → Add to Home Screen (PWA).

CDN (may lag behind local):  
https://cdn.jsdelivr.net/gh/justinbusiness461-lab/pulseforge-songforge@main/index.html

## What ships
| Phase | Capability |
|-------|------------|
| 1 | Natural-language prompt → integer-tick SongSpec, 16-step matrix, mixer |
| 2 | Detuned dual-saw bass, dual-op FM pads/leads, Karplus-Strong plucks |
| 3 | Lyric → phoneme timeline, formant vocals (male/female), MEG visemes |
| 4 | Asymmetric tape saturation on master + stereo BBD spatial delay send |

## Files (production)
- `index.html` — thumbs-first UI + safe-area dock
- `app-core.js` — prompt compiler + DSP engines + transport
- `app-ui.js` — mixer, matrix, export, load
- `manifest.json` + `service-worker.js` + `icons/` — PWA

## Exports
- **Save JSON** — full Score Graph
- **Cinema Graph** — Music Event Graph v2 (sections + PHONEME/viseme)
- **WAV** — offline mix render

## Evidence ceiling
Deterministic local Web Audio only. Not neural singing, not Suno/Udio, not hardware tape/BBD parity.
