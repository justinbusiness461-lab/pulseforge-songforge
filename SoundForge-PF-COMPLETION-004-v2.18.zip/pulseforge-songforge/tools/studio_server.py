#!/usr/bin/env python3
"""S.A.R.A. Sound Forge local studio server — PWA + disk writes + hybrid + vocal lab."""
from __future__ import annotations

import http.server
import json
import math
import os
import socketserver
import struct
import sys
from pathlib import Path
from urllib.parse import unquote

PORT = int(os.environ.get("STUDIO_PORT", "8765"))
ROOT = Path(__file__).resolve().parent.parent
EXPORT_ROOT = ROOT / "workspace" / "studio_exports"

import hashlib
from datetime import datetime, timezone

MANIFEST_LOG_PATH = EXPORT_ROOT / "manifest_registry.json"


def append_to_integrity_manifest(filename: str, subdirectory: str, absolute_path: str, data_bytes: bytes) -> str:
    """Append-only SHA-256 ledger for production writes."""
    sha256 = hashlib.sha256(data_bytes).hexdigest()
    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "filename": filename,
        "subdirectory": subdirectory,
        "absolute_path": absolute_path,
        "sha256_checksum": f"sha256:{sha256}",
        "bytes_written": len(data_bytes),
    }
    registry = []
    if MANIFEST_LOG_PATH.exists():
        try:
            registry = json.loads(MANIFEST_LOG_PATH.read_text(encoding="utf-8"))
            if not isinstance(registry, list):
                registry = []
        except Exception:
            registry = []
    registry.append(entry)
    staging = MANIFEST_LOG_PATH.with_suffix(".json.tmp")
    staging.write_text(json.dumps(registry, indent=2), encoding="utf-8")
    os.replace(staging, MANIFEST_LOG_PATH)
    print(f"[Integrity-Ledger] {filename} sha256:{sha256[:16]}…")
    return sha256


def atomic_write_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    staging = path.with_suffix(path.suffix + ".tmp")
    with open(staging, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(staging, path)


def write_stereo_wav(path: Path, duration_sec: float = 8.0, bpm: float = 102.0) -> int:
    sample_rate = 44100
    n = int(sample_rate * duration_sec)
    frames = bytearray()
    beat = 60.0 / max(40.0, bpm)
    for s in range(n):
        t = s / sample_rate
        env = min(1.0, t * 4) * max(0.0, 1.0 - (t / duration_sec) * 0.85)
        phase = (t % beat) / beat
        kick = math.sin(2 * math.pi * (80 - 40 * phase) * t) * math.exp(-phase * 8) * 0.35
        bass = math.sin(2 * math.pi * 55 * t) * 0.2 * env
        hat = (1 if (s % max(1, int(sample_rate * beat / 4))) < 80 else 0) * 0.08
        mid = math.sin(2 * math.pi * 220 * t) * 0.06 * env
        l = kick + bass + hat + mid
        r = kick * 0.9 + bass * 1.05 + hat * 0.85 + mid * 1.1
        frames += struct.pack(
            "<hh",
            max(-32767, min(32767, int(l * 32767))),
            max(-32767, min(32767, int(r * 32767))),
        )
    data_size = len(frames)
    header = b"RIFF" + struct.pack("<I", 36 + data_size) + b"WAVEfmt "
    header += struct.pack("<IHHIIHH", 16, 1, 2, sample_rate, sample_rate * 4, 4, 16)
    header += b"data" + struct.pack("<I", data_size)
    atomic_write_bytes(path, header + frames)
    return data_size


class StudioHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def log_message(self, fmt, *args):
        print(f"[Studio-Server] {fmt % args}")

    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Access-Control-Allow-Origin", "*")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def _json(self, code: int, obj: dict):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        path = unquote(self.path.split("?", 1)[0])
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length) if length else b"{}"
        try:
            payload = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError as e:
            self._json(400, {"status": "ERROR", "error": str(e)})
            return

        if path == "/api/write_production_file":
            self._handle_write(payload)
            return
        if path == "/api/dispatch_neural_compilation":
            self._handle_neural(payload)
            return
        if path == "/api/local_neural_vocal_synthesis":
            self._handle_vocal_lab(payload)
            return
        self.send_error(404, "Not found")

    def _handle_write(self, payload: dict):
        filename = Path(str(payload.get("filename") or "export.bin")).name
        sub = "".join(
            c if c.isalnum() or c in "-_" else "_"
            for c in str(payload.get("subdirectory") or "exports")
        )[:64]
        data_bytes = payload.get("data_bytes")
        if data_bytes is None:
            self._json(400, {"status": "ERROR", "error": "data_bytes required"})
            return
        if isinstance(data_bytes, str):
            data = data_bytes.encode("utf-8")
        elif isinstance(data_bytes, list):
            data = bytes(int(x) & 0xFF for x in data_bytes)
        else:
            self._json(400, {"status": "ERROR", "error": "bad data_bytes"})
            return
        if len(data) > 50 * 1024 * 1024:
            self._json(413, {"status": "ERROR", "error": "too large"})
            return
        dest = EXPORT_ROOT / sub / filename
        try:
            atomic_write_bytes(dest, data)
        except OSError as e:
            self._json(500, {"status": "ERROR", "error": str(e)})
            return
        print(f"[Studio-Server] wrote {dest} ({len(data)} bytes)")
        digest = append_to_integrity_manifest(filename, sub, str(dest.resolve()), data)
        self._json(200, {"status": "SUCCESS", "saved_at": str(dest.resolve()), "bytes": len(data), "sha256": digest})

    def _handle_neural(self, request_data: dict):
        try:
            title = str(request_data.get("title") or "SARA_RELEASE_TRACK")
            safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in title)[:80]
            cfg = request_data.get("configuration") or {}
            bpm = float(cfg.get("target_bpm") or 102)
            scale = str(cfg.get("target_scale") or "F# minor")
            lyrics = str(request_data.get("lyrics") or "")
            prompt = str(request_data.get("prompt_directive") or "")
            masters = EXPORT_ROOT / "production_masters"
            otio_dir = EXPORT_ROOT / "otio_packages"
            masters.mkdir(parents=True, exist_ok=True)
            otio_dir.mkdir(parents=True, exist_ok=True)
            wav_path = masters / f"{safe}_broadcast_master.wav"
            otio_path = otio_dir / f"{safe}_broadcast_interchange.otio.json"
            duration = 8.0
            nbytes = write_stereo_wav(wav_path, duration_sec=duration, bpm=bpm)
            otio = {
                "OTIO_SCHEMA": "Timeline.1",
                "name": f"{title} Broadcast Master Timeline",
                "metadata": {
                    "neural_provider_attribution": "SARA_LOCAL_HYBRID_PROXY",
                    "model_version_pin": "local_deterministic_wav_proxy_v1",
                    "target_bpm": bpm,
                    "target_scale": scale,
                    "prompt_directive": prompt[:500],
                    "lyrics_character_count": len(lyrics),
                },
                "tracks": {
                    "OTIO_SCHEMA": "Stack.1",
                    "name": "Tracks Stack",
                    "children": [
                        {
                            "OTIO_SCHEMA": "Track.1",
                            "name": "Vocal Broadcast Channel",
                            "kind": "Video",
                            "children": [
                                {
                                    "OTIO_SCHEMA": "Clip.1",
                                    "name": "Hybrid_Performance_Block",
                                    "source_range": {
                                        "OTIO_SCHEMA": "TimeRange.1",
                                        "start_time": {
                                            "OTIO_SCHEMA": "RationalTime.1",
                                            "rate": 30,
                                            "value": 0,
                                        },
                                        "duration": {
                                            "OTIO_SCHEMA": "RationalTime.1",
                                            "rate": 30,
                                            "value": int(duration * 30),
                                        },
                                    },
                                }
                            ],
                        }
                    ],
                },
            }
            atomic_write_bytes(otio_path, json.dumps(otio, indent=2).encode("utf-8"))
            print(f"[Studio-Server] hybrid master {wav_path} ({nbytes} PCM bytes)")
            self._json(
                200,
                {
                    "status": "SUCCESS",
                    "saved_master_path": str(wav_path.resolve()),
                    "saved_otio_path": str(otio_path.resolve()),
                    "provider": "local_hybrid_proxy",
                },
            )
        except Exception as e:
            print(f"[Studio-Server] neural fault: {e}")
            self._json(500, {"status": "ERROR", "error": str(e)})

    def _handle_vocal_lab(self, request_data: dict):
        try:
            tools = str(Path(__file__).resolve().parent)
            if tools not in sys.path:
                sys.path.insert(0, tools)
            from vocal_lab import render_vocal_job

            result = render_vocal_job(request_data, EXPORT_ROOT)
            print(f"[Vocal-Lab] {result.get('engine')} → {result.get('saved_master_path')}")
            self._json(200, result)
        except Exception as e:
            print(f"[Vocal-Lab] fault: {e}")
            self._json(500, {"status": "ERROR", "error": str(e)})


def main():
    EXPORT_ROOT.mkdir(parents=True, exist_ok=True)
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", PORT), StudioHandler) as httpd:
        print("=" * 72)
        print(f"[Studio-Server] http://localhost:{PORT}")
        print(f"[Studio-Server] root {ROOT}")
        print(f"[Studio-Server] exports {EXPORT_ROOT}")
        print("[Studio-Server] POST /api/write_production_file")
        print("[Studio-Server] POST /api/dispatch_neural_compilation")
        print("[Studio-Server] POST /api/local_neural_vocal_synthesis")
        print("=" * 72)
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n[Studio-Server] shutdown")
            sys.exit(0)


if __name__ == "__main__":
    main()
