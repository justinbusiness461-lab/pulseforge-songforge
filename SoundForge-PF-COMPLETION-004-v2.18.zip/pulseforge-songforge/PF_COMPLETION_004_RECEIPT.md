# PF-COMPLETION-004 Receipt

**Environment:** `/home/workdir/artifacts/pulseforge-songforge`  
**Git HEAD:** NONE (workspace is not a verified live git clone)  
**Reported commits in prior pastes:** NOT independently verified in this environment

## Reproduced vs reported

| Claim from prior receipts | This cycle |
|---------------------------|------------|
| v2.18 ZIPs exist | **FALSE** — only through v2.17 existed before this cycle |
| forge_vocal_lead_Master_Timeline.otio | **NOT FOUND** (fabricated path in narrative receipts) |
| Full C6 UI automation with real Play | **NOT run** (no browser automation of full Play in this cycle) |
| OTIO valid pass / malformed fail | **REPRODUCED** on preserved + adversarial **copy** |
| Ledger content-identity | **REPRODUCED** via new `certify_integrity.py` |
| Missing-file ledger entry fails | **REPRODUCED** exit 1 |

## Test matrix (actual)

| Test | Command | Exit |
|------|---------|------|
| Good OTIO | `python3 tools/certify_otio.py .../pf004_journey_good.otio.json` | 0 |
| Adversarial copy | same on `pf004_journey_adversarial_copy.otio.json` | 1 |
| Integrity | `python3 tools/certify_integrity.py` | 0 |
| Integrity mismatch | synthetic ledger with missing path | 1 |

## Artifacts preserved
- `workspace/studio_exports/otio_packages/pf004_journey_good.otio.json`
- sha256: `26be326b6720d9fd49c09cca384fe354dcef99b0d9830a3d111e086c18d8948e`
- Adversarial tests used a **copy**; good fixture not destroyed

## Release boundary finding
`SoundForge-Studio-Release-v2.17.zip` **omitted** `studio_server.py`, `vocal_lab.py`, `certify_otio.py` — clean install could not complete broker journey from that ZIP alone. Packager updated for v2.18.

## Five-person validation
**Not conducted.** Protocol documented in `COMMERCIAL_OFFER_STAGE1.md`.

## Sellable now (honest)
Local workstation kit with arrangement, playback, structural OTIO, integrity content-identity, guide vocals — **if** distributed with complete tools (v2.18+).

## Not sellable as
AI music-video product, commercial SVS, zero-touch SaaS.

## Cinema
Armature/viseme preview only. Headless finished-film path still missing.

## Highest-leverage next
**Owner:** Commercial Validation (human)  
**Action:** Recruit 5 producers for the protocol in COMMERCIAL_OFFER_STAGE1.md using v2.18 complete ZIP.  
**Done when:** installation success rate + WTP notes recorded (not assumed).
