# Stage 1 Offer — Local Production Workstation Kit

**Status:** Candidate for paid pilot validation — not market-proven.

## Deliverables (verified capabilities only)
- Browser multi-track Score Graph arrangement (prompt → sections/tracks/NOTE_ON)
- Local Web Audio playback (waveguide/FM/formant guides, shelves, spatial BBD, master compressor)
- Structural OTIO-inspired JSON export + `certify_otio.py`
- SHA-256 write ledger + `certify_integrity.py` (content identity)
- Vocal Lab formant / production-torch stems (guide quality)
- Local Python studio server for disk writes

## Explicit exclusions
- Autonomous finished 3D music video / BAD HABIT film delivery
- Commercial neural singing parity (requires customer-supplied ONNX weights)
- Hosted SaaS, cloud generation APIs, or zero-touch install

## Customer requirements
- Run `python3 tools/studio_server.py` themselves
- Modern browser; own lyrics/content rights

## Economics (hypotheses — not measured sales)
| Item | Assumption |
|------|------------|
| Price test | $49 one-time license (hypothesis) |
| Cloud marginal cost | $0 for core path |
| Support labor | estimate 1–2 h per install until self-serve polish |
| Validation | 5 independent producers — **not yet conducted** |

## Validation protocol (ready, not executed)
1. Clean install from release ZIP
2. Cold open → Compile → Play → Export → certify_otio + certify_integrity
3. Record: success/fail, time, assistance, willingness-to-pay, actual payment if any

## Gate recommendation
**Technical gate:** partially met (tools exist; release ZIP must include server tools — fixed in v2.18).
**Customer gate:** not met (0 independent testers run).
**Commercial gate:** not met (no purchase evidence).

Do not scale marketing until Gates 2–3 produce evidence.
